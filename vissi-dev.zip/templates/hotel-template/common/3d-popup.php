<div id="PopUp3d" class="hide popup-box">
    <div id="bookScroller">
<!--         <div id="bookPopUpHeader">
            
            <div class="alert alert-success" style="display:none;"></div>
            <div class="alert alert-danger" style="display:none;"></div>
        </div> -->
        <div id="bookPopUpContent" style="width: 100%;">
            <img src="<?= $path3d ?>" />
        </div>
    </div>
</div>