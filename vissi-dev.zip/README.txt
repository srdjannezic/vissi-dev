Panda Resort 6 for single Hotel
Documentation: https://resort.pandao.eu/doc/
Author: Pandao
Web: https://items.pandao.eu
